
// ================================================================================
// TG Links: bot=t.me/imguisource_bot main=t.me/ImGui_Source_FIXNEY extra=t.me/il2cpp_src
// ================================================================================

//pasted✅
#pragma once
#include <algorithm>
#include <atomic>
#include <chrono>
#include <cmath>
#include <cstdio>
#include <cstring>
#include <mutex>
#include <string>
#include <vector>

#include "imgui.h"
#include "imgui_internal.h"

#include "features/aim/assists.hpp"
#include "features/aim/automation.hpp"
#include "features/aim/core.hpp"
#include "features/aim/silent_diagnostics.hpp"
#include "features/visuals/astra_camera_test.hpp"
#include "features/visuals/astra_hitlog.hpp"
#include "features/visuals/astra_night.hpp"
#include "features/visuals/esp_runtime.hpp"
#include "ui/xevilight/theme.hpp"
#include "ui/xevilight/widgets.hpp"
#include "ui/skin_gallery.hpp"

using EspScreenBox = astra::esp::ScreenBox;
extern std::vector<EspScreenBox> g_espScreenBoxes;
extern std::mutex g_espMutex;
extern std::atomic<bool> g_espBoxesEnabled;
extern std::atomic<bool> g_offsetProfileReady;
extern std::atomic<std::uintptr_t> g_unityBase;

static bool menuOpen() { return g_menuOpen.load(std::memory_order_relaxed); }
static void setMenuOpen(bool open) { g_menuOpen.store(open, std::memory_order_relaxed); }

struct KwB {
    bool esp_enabled = false, esp_box = true, esp_hp = true, esp_armor = true;
    bool esp_wep = true, esp_ammo = true;
};
static KwB g_b;

static ImVec4 g_espBoxCol{.94f, .95f, .97f, 1.f};
static ImVec4 g_espHpCol{.36f, .87f, .65f, 1.f};
static ImVec4 g_espWepCol{.91f, .92f, .95f, 1.f};
static ImVec4 g_espAmmoCol{.68f, .72f, .79f, 1.f};
static float g_S = 1.f;  // ESP optical scale, set each frame by the shell

// These two read the globals above at include time.
#include "ui/premium_arrows.hpp"
#include "ui/premium_esp_extra.hpp"

namespace xevm {

using namespace xev::ui;

// ── shell state ─────────────────────────────────────────────────────────────
constexpr int kTabs = 4;
static const char* kTabNames[kTabs] = {XS("Rage"), XS("Visuals"), XS("Skins"), XS("Settings")};

static int g_tab = 0;
static ImVec2 g_pos{-1.f, -1.f}, g_screen{0.f, 0.f};
static bool g_watermark = true;
static bool g_preview = true;
static float g_menuScale = 100.f;
static float g_scroll[kTabs]{}, g_target[kTabs]{}, g_content[kTabs]{};
static bool g_headerHeld = false;

static astra::aim::Configuration edit;
static bool g_dirty = false, g_reset = false;

// ── FOV projection ──────────────────────────────────────────────────────────
struct Projection {
    float width = 0, height = 0, p00 = 0, p11 = 0, shiftX = 0, shiftY = 0;
    double captured = 0;
};
static std::mutex projectionMutex;
static Projection projection;

static double nowSeconds() {
    return std::chrono::duration<double>(std::chrono::steady_clock::now().time_since_epoch()).count();
}

static void clearProjection() {
    std::lock_guard<std::mutex> guard(projectionMutex);
    projection = {};
}

static void updateProjection() {
    auto config = astra::aim::configuration();
    if (!config.normal.showFov && !config.silent.showFov) {
        clearProjection();
        return;
    }
    astra::esp::CameraMatrixCache cache{};
    std::uintptr_t camera = 0;
    if (!astra::esp::detail::readCameraForPresent(cache, camera)) {
        clearProjection();
        return;
    }
    const auto& p = cache.projection.value;
    const float scale = -p[11];
    if (!std::isfinite(scale) || scale <= .0001f) {
        clearProjection();
        return;
    }
    for (int index : {1, 3, 4, 7, 12, 13, 15})
        if (std::fabs(p[index] / scale) > .001f) {
            clearProjection();
            return;
        }
    const ImVec2 size = ImGui::GetIO().DisplaySize;
    const float p00 = std::fabs(p[0] / scale), p11 = std::fabs(p[5] / scale);
    const float sx = p[8] / scale, sy = p[9] / scale;
    const auto geometry = astra::aim::assists::fovGeometry(std::max(config.normal.fov, config.silent.fov),
                                                           size.x, size.y, p00, p11, sx, sy);
    if (!geometry.valid) {
        clearProjection();
        return;
    }
    std::lock_guard<std::mutex> guard(projectionMutex);
    projection = {size.x, size.y, p00, p11, sx, sy, nowSeconds()};
}

static astra::aim::assists::FovGeometry fovGeometry(float degrees) {
    Projection snapshot;
    {
        std::lock_guard<std::mutex> guard(projectionMutex);
        snapshot = projection;
    }
    const ImVec2 display = ImGui::GetIO().DisplaySize;
    const double age = nowSeconds() - snapshot.captured;
    if (age < 0 || age >= .25 || std::fabs(snapshot.width - display.x) > 1 || std::fabs(snapshot.height - display.y) > 1)
        return {};
    return astra::aim::assists::fovGeometry(degrees, snapshot.width, snapshot.height, snapshot.p00, snapshot.p11,
                                            snapshot.shiftX, snapshot.shiftY);
}

static void renderFov(const astra::aim::Settings& settings, ImU32 color) {
    if (!settings.showFov) return;
    const auto geometry = fovGeometry(settings.fov);
    if (!geometry.valid || geometry.coversScreen) return;
    auto* draw = ImGui::GetBackgroundDrawList();
    draw->PushClipRect(ImVec2(0, 0), ImGui::GetIO().DisplaySize, true);
    draw->PathClear();
    for (int i = 0; i <= 256; ++i) {
        const float a = float(i) * 6.28318530718f / 256.f;
        draw->PathLineTo(ImVec2(geometry.centerX + std::cos(a) * geometry.radiusX,
                                geometry.centerY + std::sin(a) * geometry.radiusY));
    }
    draw->PathStroke(color, 0, 1.6f);
    draw->PopClipRect();
}

static void renderEsp() {
    if (!g_b.esp_enabled || !g_espBoxesEnabled.load()) return;
    std::vector<EspScreenBox> boxes;
    {
        std::lock_guard<std::mutex> guard(g_espMutex);
        boxes = g_espScreenBoxes;
    }
    auto* draw = ImGui::GetBackgroundDrawList();
    draw->PushClipRect(ImVec2(0, 0), ImGui::GetIO().DisplaySize, true);
    for (const auto& box : boxes) astra_esp_extra::draw(draw, box);
    draw->PopClipRect();
}

// ── preview ─────────────────────────────────────────────────────────────────
static void previewPanel() {
    const ImRect box(L.x0, L.y + px(2.f), L.x1, L.y + px(2.f) + px(132.f));
    auto* draw = L.dl;
    draw->AddRectFilled(box.Min, box.Max, IM_COL32(10, 10, 11, 255), px(6.f));
    for (float gx = box.Min.x + px(14.f); gx < box.Max.x; gx += px(22.f))
        draw->AddLine(ImVec2(gx, box.Min.y), ImVec2(gx, box.Max.y), IM_COL32(255, 255, 255, 5));
    for (float gy = box.Min.y + px(14.f); gy < box.Max.y; gy += px(22.f))
        draw->AddLine(ImVec2(box.Min.x, gy), ImVec2(box.Max.x, gy), IM_COL32(255, 255, 255, 5));

    const float cx = box.GetCenter().x, top = box.Min.y + px(16.f), bottom = box.Max.y - px(18.f);
    const float bw = std::min((box.GetWidth()) * .42f, px(84.f));
    const float bodyH = bottom - top;
    const ImU32 ink = IM_COL32(64, 68, 78, 255);
    draw->AddCircleFilled(ImVec2(cx, top + bodyH * .09f), bodyH * .065f, ink, 24);
    draw->AddRectFilled(ImVec2(cx - bw * .16f, top + bodyH * .17f), ImVec2(cx + bw * .16f, top + bodyH * .59f), ink,
                        px(4.f));
    for (int side : {-1, 1}) {
        draw->AddLine(ImVec2(cx + side * bw * .20f, top + bodyH * .22f), ImVec2(cx + side * bw * .31f, top + bodyH * .61f),
                      ink, px(7.f));
        draw->AddLine(ImVec2(cx + side * bw * .08f, top + bodyH * .56f), ImVec2(cx + side * bw * .18f, bottom),
                      ink, px(8.f));
    }
    if (g_b.esp_enabled) {
        EspScreenBox sample{};
        sample.left = cx - bw * .5f;
        sample.right = cx + bw * .5f;
        sample.top = top;
        sample.bottom = bottom;
        sample.enemy = true;
        sample.statsValid = true;
        sample.weaponValid = true;
        sample.hp = astra_esp_extra::settings.lowHealth ? 20 : 74;
        sample.maxHp = 100;
        sample.armor = 60;
        sample.maxArmor = 100;
        sample.weaponId = 7;
        sample.magazineAmmo = astra_esp_extra::settings.emptyMagazine ? 0 : 24;
        sample.reserveAmmo = 90;
        sample.distanceUnits = 24.f;
        sample.distanceValid = true;
        astra_esp_extra::draw(draw, sample);
    }
    draw->AddRect(box.Min, box.Max, kHair, px(6.f), 0, px(1.f));
    L.y = box.Max.y + px(10.f);
}

// ── pages ───────────────────────────────────────────────────────────────────
static void resetAll();

static void pageRage() {
    section(XS("Aim"));
    if (toggle(XS("aim.on"), edit.normal.enabled, XS("Aim"))) g_dirty = true;
    if (toggle(XS("aim.visible"), edit.normal.visibleCheck, XS("Visible check"))) g_dirty = true;
    if (toggle(XS("aim.showfov"), edit.normal.showFov, XS("Show FOV"))) g_dirty = true;
    if (toggle(XS("aim.rcs"), edit.normal.rcs, XS("Recoil control"))) g_dirty = true;
    if (slider(XS("aim.fov"), XS("FOV"), edit.normal.fov, 1.f, 180.f, XS("%.0f deg"))) g_dirty = true;
    if (slider(XS("aim.smooth"), XS("Smoothing"), edit.normal.smoothing, 0.f, 1.f, XS("%.2f s"))) g_dirty = true;
    if (slider(XS("aim.rcsstr"), XS("RCS strength"), edit.normal.rcsStrength, 0.f, 100.f, XS("%.0f%%"))) g_dirty = true;
    if (toggle(XS("aim.pred"), edit.normal.prediction, XS("Prediction"))) g_dirty = true;
    if (slider(XS("aim.tick"), XS("Prediction tick"), edit.normal.predictionTicks, 0.f, 10.f, XS("%.0f tick"))) g_dirty = true;
    if (toggle(XS("aim.back"), edit.normal.backCamera, XS("Back camera"))) g_dirty = true;

    section(XS("Target"));
    if (chips(XS("aim.bodies"), edit.normal.bodies, astra::aim::kBodyNames, 8)) g_dirty = true;
    static const char* priorities[] = {XS("Angle"), XS("Distance"), XS("Health")};
    selectRow(XS("aim.priority"), XS("Priority"), edit.normal.priority, priorities, 3, &g_dirty);

    section(XS("Silent aim"));
    if (toggle(XS("silent.on"), edit.silent.enabled, XS("Silent aim"))) g_dirty = true;
    if (toggle(XS("silent.visible"), edit.silent.visibleCheck, XS("Visible check"))) g_dirty = true;
    if (toggle(XS("silent.showfov"), edit.silent.showFov, XS("Show FOV"))) g_dirty = true;
    if (toggle(XS("silent.lock"), edit.silent.lockTarget, XS("Lock target"))) g_dirty = true;
    if (toggle(XS("silent.multi"), edit.silent.multipoints, XS("Multipoints"))) g_dirty = true;
    if (toggle(XS("silent.pred"), edit.silent.prediction, XS("Prediction"))) g_dirty = true;
    if (slider(XS("silent.fov"), XS("Silent FOV"), edit.silent.fov, 1.f, 180.f, XS("%.0f deg"))) g_dirty = true;
    if (slider(XS("silent.dist"), XS("Max distance"), edit.silent.maxDistance, 10.f, 300.f, XS("%.0f m"))) g_dirty = true;
    if (slider(XS("silent.scale"), XS("Point scale"), edit.silent.pointScale, 0.f, .9f, XS("%.2f"))) g_dirty = true;
    if (slider(XS("silent.tick"), XS("Prediction tick"), edit.silent.predictionTicks, 0.f, 10.f, XS("%.0f tick"))) g_dirty = true;
    if (slider(XS("silent.lead"), XS("Extra lead"), edit.silent.predictionMs, -150.f, 150.f, XS("%.0f ms"))) g_dirty = true;

    section(XS("Automation"));
    if (toggle(XS("auto.on"), edit.autoFire.enabled, XS("Autofire"))) g_dirty = true;
    if (toggle(XS("auto.scope"), edit.autoFire.autoScope, XS("Auto scope"))) g_dirty = true;
    if (slider(XS("auto.interval"), XS("Shot interval"), edit.autoFire.intervalMs, 30.f, 1000.f, XS("%.0f ms"))) g_dirty = true;

    section(XS("Anti-aim"));
    auto& aa = edit.antiAim;
    if (toggle(XS("aa.on"), aa.enabled, XS("Anti-aim"))) g_dirty = true;
    if (toggle(XS("aa.model"), aa.localModel, XS("Local model"))) g_dirty = true;
    static const char* aaPitch[] = {XS("Up"), XS("Down"), XS("Fake down")};
    static const char* aaYaw[] = {XS("Backward"), XS("Spin"), XS("Flick")};
    selectRow(XS("aa.pitch"), XS("Pitch"), aa.pitchMode, aaPitch, 3, &g_dirty);
    selectRow(XS("aa.yaw"), XS("Yaw"), aa.yawMode, aaYaw, 3, &g_dirty);
    if (aa.yawMode == 0 || aa.yawMode == 2) {
        if (slider(XS("aa.offset"), XS("Yaw offset"), aa.offset, -180.f, 180.f, XS("%.0f deg"))) g_dirty = true;
    }
    if (aa.yawMode == 1) {
        if (slider(XS("aa.speed"), XS("Spin speed"), aa.speed, 30.f, 720.f, XS("%.0f deg/s"))) g_dirty = true;
    }
    if (aa.yawMode == 2) {
        if (slider(XS("aa.flick"), XS("Flick angle"), aa.flickAngle, 5.f, 90.f, XS("%.0f deg"))) g_dirty = true;
        if (slider(XS("aa.flickrate"), XS("Flick rate"), aa.flickRate, .5f, 10.f, XS("%.1f Hz"))) g_dirty = true;
    }
    if (aa.pitchMode == 2) {
        if (slider(XS("aa.fakerate"), XS("Fake rate"), aa.fakeRate, .5f, 10.f, XS("%.1f Hz"))) g_dirty = true;
    }
}

static void pageVisuals() {
    section(XS("ESP"));
    toggle(XS("esp.on"), g_b.esp_enabled, XS("Player ESP"));
    toggle(XS("esp.box"), g_b.esp_box, XS("Bounding box"));
    toggle(XS("esp.hp"), g_b.esp_hp, XS("Health bar"));
    toggle(XS("esp.armor"), g_b.esp_armor, XS("Armor bar"));
    toggle(XS("esp.wep"), g_b.esp_wep, XS("Weapon info"));
    toggle(XS("esp.ammo"), g_b.esp_ammo, XS("Ammo"));
    colorRow(XS("esp.boxcol"), XS("Box color"), g_espBoxCol, nullptr);
    colorRow(XS("esp.hpcol"), XS("Health color"), g_espHpCol, nullptr);
    colorRow(XS("esp.armorcol"), XS("Armor color"), astra_esp_extra::settings.armorColor, nullptr);
    colorRow(XS("esp.wepcol"), XS("Weapon color"), g_espWepCol, nullptr);
    colorRow(XS("esp.ammocol"), XS("Ammo color"), g_espAmmoCol, nullptr);

    section(XS("Frame"));
    auto& style = astra_esp_extra::settings;
    static const char* frames[] = {XS("Classic"), XS("Corners"), XS("Rounded"), XS("Dashed"), XS("Side brackets")};
    selectRow(XS("esp.frame"), XS("Frame style"), astra_esp_extra::frameStyle, frames, 5, nullptr);
    toggle(XS("esp.fill"), style.fill, XS("Box fill"));
    slider(XS("esp.fillalpha"), XS("Fill opacity"), style.fillAlpha, 0.f, .35f, XS("%.2f"));
    toggle(XS("esp.snap"), style.snaplines, XS("Snaplines"));
    toggle(XS("esp.head"), style.headMarker, XS("Head marker"));
    toggle(XS("esp.shadow"), style.shadow, XS("Text shadow"));
    toggle(XS("esp.outline"), style.outline, XS("Text outline"));
    slider(XS("esp.thick"), XS("Line width"), style.thickness, 1.f, 4.f, XS("%.1f"));
    slider(XS("esp.text"), XS("Text scale"), style.textScale, .5f, 2.f, XS("%.2f"));
    toggle(XS("esp.div"), astra_esp_extra::barDivisions, XS("HP / armor divisions"));

    section(XS("Information"));
    toggle(XS("esp.dist"), style.distance, XS("Distance"));
    toggle(XS("esp.hpnum"), style.hpNumber, XS("HP number"));
    toggle(XS("esp.armornum"), style.armorNumber, XS("Armor number"));
    toggle(XS("esp.low"), style.lowHealth, XS("Low health marker"));
    slider(XS("esp.lowpct"), XS("Low HP threshold"), style.lowHealthPercent, 5.f, 50.f, XS("%.0f%%"));
    toggle(XS("esp.empty"), style.emptyMagazine, XS("Empty magazine"));

    section(XS("Arrows"));
    toggle(XS("arrow.on"), astra_arrows::settings.enabled, XS("Off-screen arrows"));
    toggle(XS("arrow.glow"), astra_arrows::settings.glow, XS("Arrow halo"));
    colorRow(XS("arrow.color"), XS("Arrow color"), astra_arrows::settings.color, nullptr);
    slider(XS("arrow.size"), XS("Arrow size"), astra_arrows::settings.size, 7.f, 24.f, XS("%.0f px"));
    slider(XS("arrow.inset"), XS("Arrow inset"), astra_arrows::settings.inset, 30.f, 180.f, XS("%.0f px"));

    section(XS("World"));
    astra_night::Settings night = astra_night::configuration();
    bool nightChanged = toggle(XS("night.on"), night.enabled, XS("GPU night mode"));
    float strength = night.strength * 100.f;
    if (slider(XS("night.strength"), XS("Night strength"), strength, 0.f, 100.f, XS("%.0f%%"))) {
        night.strength = std::clamp(strength * .01f, 0.f, 1.f);
        nightChanged = true;
    }
    if (nightChanged) astra_night::publish(night);

    section(XS("Camera"));
    astra_camera_test::V camera;
    {
        std::lock_guard<std::mutex> guard(astra_camera_test::lock);
        camera = astra_camera_test::settings;
    }
    bool cameraOn = astra_camera_test::enabled.load();
    bool cameraChanged = toggle(XS("cam.on"), cameraOn, XS("Third person camera"));
    cameraChanged |= slider(XS("cam.height"), XS("Camera height"), camera.y, 0.f, 4.f, XS("%.2f m"));
    cameraChanged |= slider(XS("cam.distance"), XS("Camera distance"), camera.z, .5f, 8.f, XS("%.2f m"));
    if (cameraChanged) {
        astra_camera_test::enabled.store(cameraOn);
        astra_camera_test::restore_requested.store(!cameraOn);
        if (cameraOn) astra_camera_test::lease.store(astra_camera_test::nowMs());
        astra_camera_test::resetSmoothing();
        std::lock_guard<std::mutex> guard(astra_camera_test::lock);
        astra_camera_test::settings = camera;
    }
    if (buttonRow(XS("cam.reset"), XS("Reset camera"))) astra_camera_test::reset();

    section(XS("Preview"));
    toggle(XS("esp.preview"), g_preview, XS("Show preview"));
    if (g_preview) previewPanel();
}

static void pageSkins() {
    xev::gallery::panel();
}

static void pageSettings() {
    section(XS("Interface"));
    toggle(XS("ui.watermark"), g_watermark, XS("Watermark"));
    if (slider(XS("ui.scale"), XS("Menu scale"), g_menuScale, 85.f, 130.f, XS("%.0f%%"))) {
        g_menuScale = std::clamp(g_menuScale, 85.f, 130.f);
    }
    toggle(XS("ui.preview"), g_preview, XS("ESP preview"));

    section(XS("Configuration"));
    if (buttonRow(XS("cfg.save"), XS("Save silent diagnostics"))) silent_diag::save();
    if (buttonRow(XS("cfg.reset"), XS("Reset settings"))) resetAll();
    paragraph(silent_diag::status, kTextFaint);

    section(XS("Runtime"));
    const auto unity = g_unityBase.load(std::memory_order_acquire);
    kv(XS("Binary profile"), !unity ? XS("waiting for libunity") : g_offsetProfileReady.load() ? XS("1.1.0 ARM64") : XS("mismatch"));
    kv(XS("Aim hook"), astra::aim::g_normalHookReady.load() ? XS("ready") : XS("waiting"));
    kv(XS("Silent hook"), astra::aim::g_silentHookReady.load() ? XS("ready") : XS("waiting"));
    kv(XS("ESP hook"), astra::esp::g_playerUpdateHookReady.load() ? XS("ready") : XS("waiting"));
    char frame[32];
    std::snprintf(frame, sizeof frame, XS("%.1f ms"), 1000.f / std::max(1.f, ImGui::GetIO().Framerate));
    kv(XS("Frame"), frame);
    kv(XS("UI scale"), g_menuScale > 100.f ? XS("wide") : g_menuScale < 100.f ? XS("compact") : XS("reference"));
    paragraph(XS("Monochrome shell · 700 x 450 design grid · one scale factor"), kTextFaint);
}

static void drawPage(int tab) {
    switch (tab) {
        case 0: pageRage(); break;
        case 1: pageVisuals(); break;
        case 2: pageSkins(); break;
        default: pageSettings(); break;
    }
}

// ── shell ───────────────────────────────────────────────────────────────────
static void drawPanel(const ImVec2& min, const ImVec2& max) {
    auto* draw = L.dl;
    for (int ring = 4; ring >= 1; --ring) {
        const float spread = px(3.f + ring * 4.f);
        draw->AddRectFilled(ImVec2(min.x - spread, min.y - spread), ImVec2(max.x + spread, max.y + spread),
                            IM_COL32(0, 0, 0, 7), px(6.f));
    }
    draw->AddRectFilledMultiColor(min, max, kPanelTop, kPanelTop, kPanel, kPanel);
    draw->AddRect(min, max, kEdge, px(2.f), 0, px(1.f));
    draw->AddRect(ImVec2(min.x + px(1.f), min.y + px(1.f)), ImVec2(max.x - px(1.f), max.y - px(1.f)), kHairSoft,
                  px(2.f), 0, px(1.f));
}

static void drawHeader(const ImVec2& min, float width) {
    textTracked(px(14.5f), min.x + width * .5f, min.y + px(21.f), kTitle, XS("xevilight internal"), px(.18f),
                fonts::strong);
}

static float footerHeight() { return px(46.f); }

static void drawTabs(const ImVec2& min, float width, float height) {
    const float footerTop = min.y + height - footerHeight();
    auto* draw = L.dl;
    draw->AddLine(ImVec2(min.x, footerTop), ImVec2(min.x + width, footerTop), kHair, px(1.f));

    const float cell = width / float(kTabs);
    const float cy = footerTop + footerHeight() * .5f;
    L.clipMin = min;
    L.clipMax = ImVec2(min.x + width, min.y + height);

    for (int i = 0; i < kTabs; ++i) {
        const ImRect tab(ImVec2(min.x + cell * i, footerTop), ImVec2(min.x + cell * (i + 1), min.y + height));
        const bool active = g_tab == i;
        const bool over = hover(tab);
        ImGuiID id = ImGui::GetID(kTabNames[i]);
        if (tap(tab, id)) g_tab = i;

        const ImU32 ink = active ? IM_COL32(255, 255, 255, 255)
                                 : over ? IM_COL32(255, 255, 255, 150) : IM_COL32(255, 255, 255, 108);
        textC(px(13.5f), tab.GetCenter().x, cy, ink, kTabNames[i], active ? fonts::strong : fonts::body);
        if (active) {
            float& marker = animate(id ^ 0xA5A5u, 0.f);
            toward(marker, 1.f, 18.f);
            const float inset = px(6.f);
            const float y = min.y + height - px(2.5f);
            draw->AddRectFilled(ImVec2(tab.Min.x + inset, y - px(1.5f)), ImVec2(tab.Max.x - px(12.f), y + px(1.5f)),
                                kActive, px(1.f));
        }
    }
}

static void drawScrollIndicator(const ImVec2& min, float width, float contentTop, float contentBottom, float contentH) {
    const float view = contentBottom - contentTop;
    if (contentH <= view + 1.f) return;
    const float trackX = min.x + width - px(5.f);
    const float trackH = view - px(8.f);
    const float thumbH = std::max(px(28.f), trackH * view / contentH);
    const float maxScroll = std::max(1.f, contentH - view);
    const float t = std::clamp(g_scroll[g_tab] / maxScroll, 0.f, 1.f);
    const float y = contentTop + px(4.f) + (trackH - thumbH) * t;
    L.dl->AddRectFilled(ImVec2(trackX, contentTop + px(4.f)), ImVec2(trackX + px(2.f), contentTop + px(4.f) + trackH),
                        IM_COL32(255, 255, 255, 8), px(1.f));
    L.dl->AddRectFilled(ImVec2(trackX, y), ImVec2(trackX + px(2.f), y + thumbH), IM_COL32(255, 255, 255, 46), px(1.f));
}

static void frameShell() {
    ImGuiIO& io = ImGui::GetIO();
    const ImVec2 screen = io.DisplaySize;
    const float scale = std::clamp(screen.y / 768.f, .9f, 2.6f) * (g_menuScale * .01f);
    const float width = std::min(700.f * scale, screen.x * .94f);
    const float height = std::min(450.f * scale, screen.y * .94f);
    if (width < 420.f || height < 300.f) return;

    if (g_pos.x < 0.f || g_screen.x != screen.x || g_screen.y != screen.y) {
        g_pos = ImVec2((screen.x - width) * .5f, (screen.y - height) * .5f);
        g_screen = screen;
    }
    g_pos.x = std::clamp(g_pos.x, 0.f, std::max(0.f, screen.x - width));
    g_pos.y = std::clamp(g_pos.y, 0.f, std::max(0.f, screen.y - height));

    ImGui::SetNextWindowPos(g_pos, ImGuiCond_Always);
    ImGui::SetNextWindowSize(ImVec2(width, height), ImGuiCond_Always);
    const ImGuiWindowFlags flags = ImGuiWindowFlags_NoTitleBar | ImGuiWindowFlags_NoResize |
                                   ImGuiWindowFlags_NoScrollbar | ImGuiWindowFlags_NoScrollWithMouse |
                                   ImGuiWindowFlags_NoCollapse | ImGuiWindowFlags_NoSavedSettings |
                                   ImGuiWindowFlags_NoBackground | ImGuiWindowFlags_NoBringToFrontOnFocus |
                                   ImGuiWindowFlags_NoFocusOnAppearing;
    if (!ImGui::Begin(XS("##xevilight-shell"), nullptr, flags)) {
        ImGui::End();
        return;
    }

    const ImVec2 min = ImGui::GetWindowPos();
    const ImVec2 max(min.x + width, min.y + height);
    auto* draw = ImGui::GetWindowDrawList();

    L.dl = draw;
    L.s = scale;
    L.panelMin = min;
    L.panelMax = max;
    L.mouse = io.MousePos;
    L.down = ImGui::IsMouseDown(ImGuiMouseButton_Left);
    L.pressed = ImGui::IsMouseClicked(ImGuiMouseButton_Left);
    L.released = ImGui::IsMouseReleased(ImGuiMouseButton_Left);
    L.dt = io.DeltaTime;
    L.windowHovered = ImGui::IsWindowHovered();
    L.claimed = false;
    L.interactive = !popupOpen();
    if (!L.down) g_headerHeld = false;

    // one panel, one grid
    drawPanel(min, max);
    drawHeader(min, width);
    L.clipMin = min;
    L.clipMax = max;

    const float contentTop = min.y + px(38.f);
    const float contentBottom = min.y + height - footerHeight();

    // header drag
    const ImRect header(min, ImVec2(max.x, contentTop));
    if (L.windowHovered && !popupOpen() && L.pressed && !L.claimed && header.Contains(L.mouse)) {
        g_headerHeld = true;
        L.claimed = true;
    }
    if (g_headerHeld && L.down) {
        g_pos.x = std::clamp(g_pos.x + io.MouseDelta.x, 0.f, std::max(0.f, screen.x - width));
        g_pos.y = std::clamp(g_pos.y + io.MouseDelta.y, 0.f, std::max(0.f, screen.y - height));
        L.claimed = true;
    }

    // scroll intent
    const float view = contentBottom - contentTop;
    const float maxScroll = std::max(0.f, g_content[g_tab] - view);
    if (L.windowHovered && !popupOpen() && io.MouseWheel != 0.f) {
        g_target[g_tab] -= io.MouseWheel * px(90.f);
        L.claimed = true;
    }
    if (L.pressId && L.down && !L.dragging &&
        std::fabs(L.mouse.y - L.pressPos.y) > px(9.f)) {
        L.dragging = true;
    }
    if (L.dragging && L.down) {
        g_target[g_tab] -= io.MouseDelta.y;
        L.claimed = true;
    }
    g_target[g_tab] = std::clamp(g_target[g_tab], 0.f, maxScroll);
    g_scroll[g_tab] += (g_target[g_tab] - g_scroll[g_tab]) * std::min(1.f, L.dt * 20.f);
    g_scroll[g_tab] = std::clamp(g_scroll[g_tab], 0.f, maxScroll);

    // content
    L.x0 = min.x + px(24.f);
    L.x1 = min.x + width - px(24.f);
    L.clipMin = ImVec2(min.x + px(6.f), contentTop);
    L.clipMax = ImVec2(min.x + width - px(6.f), contentBottom);
    draw->PushClipRect(L.clipMin, L.clipMax, true);
    L.y = contentTop - g_scroll[g_tab];
    drawPage(g_tab);
    g_content[g_tab] = (L.y + g_scroll[g_tab]) - contentTop;
    draw->PopClipRect();

    drawScrollIndicator(min, width, contentTop, contentBottom, g_content[g_tab]);
    drawTabs(min, width, height);

    if (popupOpen()) drawPopup();

    if (L.released) {
        L.pressId = 0;
        L.dragging = false;
    }
    ImGui::End();
}

static void drawWatermark() {
    if (!g_watermark) return;
    ImGuiIO& io = ImGui::GetIO();
    const float scale = std::clamp(io.DisplaySize.y / 768.f, .9f, 2.6f);
    auto* draw = ImGui::GetForegroundDrawList();

    const char* brand = XS("xevilight internal");
    const float size = 13.5f * scale;
    const float icon = 23.f * scale;
    const float padX = 10.f * scale, padY = 8.f * scale, gap = 9.f * scale;
    const float textW = textWidth(brand, size, fonts::strong);
    const float sepW = std::max(1.f, scale);
    const float w = padX * 2.f + icon + gap * 2.f + sepW + textW;
    const float h = icon + padY * 2.f;
    const ImRect box(ImVec2(io.DisplaySize.x - w - 20.f * scale, 18.f * scale),
                     ImVec2(io.DisplaySize.x - 20.f * scale, 18.f * scale + h));

    draw->AddRectFilled(box.Min, box.Max, IM_COL32(7, 8, 9, 212), 7.f * scale);
    draw->AddRect(box.Min, box.Max, IM_COL32(255, 255, 255, 38), 7.f * scale, 0, std::max(1.f, scale * .8f));

    const float cy = box.GetCenter().y;
    const ImRect iconBox(ImVec2(box.Min.x + padX, cy - icon * .5f),
                         ImVec2(box.Min.x + padX + icon, cy + icon * .5f));
    // monogram: two crossing strokes, the back one quieter — an x with depth
    const ImVec2 ic = iconBox.GetCenter();
    const float r = iconBox.GetWidth() * .30f;
    const float th = std::max(1.8f, scale * 2.1f);
    const ImU32 back = IM_COL32(236, 238, 243, 130);
    const ImU32 front = IM_COL32(244, 246, 250, 248);
    const ImVec2 a0(ic.x - r, ic.y + r), a1(ic.x + r, ic.y - r);
    const ImVec2 b0(ic.x + r, ic.y + r), b1(ic.x - r, ic.y - r);
    draw->AddLine(b0, b1, back, th);
    draw->AddCircleFilled(b0, th * .5f, back, 8);
    draw->AddCircleFilled(b1, th * .5f, back, 8);
    draw->AddLine(a0, a1, front, th);
    draw->AddCircleFilled(a0, th * .5f, front, 8);
    draw->AddCircleFilled(a1, th * .5f, front, 8);

    const float sepX = iconBox.Max.x + gap;
    draw->AddLine(ImVec2(sepX, cy - icon * .30f), ImVec2(sepX, cy + icon * .30f),
                  IM_COL32(255, 255, 255, 48), sepW);

    textOn(draw, size, ImVec2(sepX + gap, lineY(size, cy)), IM_COL32(255, 255, 255, 242), brand,
           fonts::strong);

    ImGui::SetNextWindowPos(box.Min, ImGuiCond_Always);
    ImGui::SetNextWindowSize(box.GetSize(), ImGuiCond_Always);
    ImGui::PushStyleVar(ImGuiStyleVar_WindowPadding, ImVec2(0, 0));
    ImGui::PushStyleVar(ImGuiStyleVar_WindowMinSize, ImVec2(1, 1));
    ImGui::PushStyleVar(ImGuiStyleVar_ItemSpacing, ImVec2(0, 0));
    const ImGuiWindowFlags wmFlags = ImGuiWindowFlags_NoTitleBar | ImGuiWindowFlags_NoResize |
                                     ImGuiWindowFlags_NoMove | ImGuiWindowFlags_NoScrollbar |
                                     ImGuiWindowFlags_NoSavedSettings | ImGuiWindowFlags_NoFocusOnAppearing |
                                     ImGuiWindowFlags_NoBringToFrontOnFocus | ImGuiWindowFlags_NoBackground |
                                     ImGuiWindowFlags_NoCollapse | ImGuiWindowFlags_NoNav;
    if (ImGui::Begin(XS("##xev-watermark"), nullptr, wmFlags)) {
        ImGui::SetCursorPos(ImVec2(0, 0));
        if (ImGui::InvisibleButton(XS("##wm"), ImGui::GetContentRegionAvail())) setMenuOpen(!menuOpen());
    }
    ImGui::End();
    ImGui::PopStyleVar(3);
}

static void resetAll() {
    astra_camera_test::reset();
    astra_arrows::reset();
    astra_esp_extra::reset();
    astra_night::publish(astra_night::Settings{});
    edit = astra::aim::Configuration{};
    g_b = KwB{};
    g_espBoxCol = ImVec4(.94f, .95f, .97f, 1.f);
    g_espHpCol = ImVec4(.36f, .87f, .65f, 1.f);
    g_espWepCol = ImVec4(.91f, .92f, .95f, 1.f);
    g_espAmmoCol = ImVec4(.68f, .72f, .79f, 1.f);
    g_dirty = true;
    g_reset = true;
}

static void commit() {
    if (!g_dirty) return;
    auto config = g_reset ? astra::aim::Configuration{} : astra::aim::configuration();
    config.normal = edit.normal;
    config.silent = edit.silent;
    config.silent.rcs = false;
    config.silent.noRecoil = false;
    config.autoFire = edit.autoFire;
    config.antiAim = edit.antiAim;
    config.pauseInMenu = edit.pauseInMenu;
    astra::aim::publish(config);
    g_dirty = false;
    g_reset = false;
}

void frame() {
    edit = astra::aim::configuration();
    g_dirty = false;
    g_reset = false;
    g_S = std::clamp(std::min(ImGui::GetIO().DisplaySize.x / 1920.f, ImGui::GetIO().DisplaySize.y / 1080.f),
                     .85f, 2.f);
    astra::aim::g_menuOpen.store(menuOpen(), std::memory_order_release);

    updateProjection();
    renderEsp();
    astra_arrows::render();
    renderFov(edit.normal, IM_COL32(240, 242, 248, 190));
    renderFov(edit.silent, IM_COL32(255, 96, 96, 190));
    if (menuOpen()) frameShell();
    drawWatermark();

    commit();
    astra::aim::g_menuOpen.store(menuOpen(), std::memory_order_release);
}

}  // namespace xevm

static void renderMinimalMenu() { xevm::frame(); }
